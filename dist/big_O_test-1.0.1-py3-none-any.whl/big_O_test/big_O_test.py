import big_O

def big_O_compare():
    print('hello world')


