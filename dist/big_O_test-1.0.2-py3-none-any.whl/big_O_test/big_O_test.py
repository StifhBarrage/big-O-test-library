from big_o import *

def big_O_compare():
    print('hello world')


